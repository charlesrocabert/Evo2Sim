/****************************************************************************
 * Copyright (C) 2014-2019 Charles Rocabert, Carole Knibbe, Guillaume Beslon
 * Web: https://github.com/charlesrocabert/Evo2Sim *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ****************************************************************************/

var ctx = document.getElementById('local_environment_chart').getContext('2d');
Chart.defaults.global.responsive = true;
var data = {
  labels: ['|3|','|7|','9','10','|11|','|17|','18','|19|'],
  datasets: [
  {
    label: 'Local environment state',
    fillColor: 'rgba(0,120,220,0.5)',
    strokeColor: 'rgba(0,120,220,0.8)',
    highlightFill: 'rgba(0,120,220,0.75)',
    highlightStroke: 'rgba(0,120,220,1)',
    data: [0.0198697,0.0786414,0.0177009,7.52326,0.0698716,0.0756064,0.0247862,0.0878452],
  }
  ]
};
var myBarChart = new Chart(ctx).Bar(data);

