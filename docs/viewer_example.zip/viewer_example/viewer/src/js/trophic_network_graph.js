/****************************************************************************
 * Copyright (C) 2014-2019 Charles Rocabert, Carole Knibbe, Guillaume Beslon
 * Web: https://github.com/charlesrocabert/Evo2Sim *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ****************************************************************************/

$(function(){ // on dom ready

var trophic_network = cytoscape({
container: document.getElementById('trophic_network_graph'),

style: cytoscape.stylesheet()
  .selector('node').css({
    'content': 'data(name)',
    'font-size': 10,
    'text-valign': 'center',
    'text-outline-width': 2,
    'shape': 'data(faveShape)',
    'text-outline-color': 'data(faveColor)',
    'background-color': 'data(faveColor)',
    'color': '#fff',
    'width': 30
  })
  .selector('edge').css({
    'opacity': 0.666,
    'target-arrow-shape': 'triangle',
    'width': 2,
    'line-color': 'data(faveColor)',
    'source-arrow-color': 'data(faveColor)',
    'target-arrow-color': 'data(faveColor)'
  })
  .selector('.highlighted').css({
    'background-color': '#61bffc',
    'line-color': '#61bffc',
    'target-arrow-color': '#61bffc',
    'transition-property': 'background-color, line-color, target-arrow-color',
    'transition-duration': '0.5s'
  }),

elements: {

nodes: [
    { data: { id: '0', name: 'ENV (10)', faveColor: 'black', faveShape: 'roundrectangle' } },
    { data: { id: '31362', name: '3-10-11 (18, 1333)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '33014', name: '3-10-11 (12, 1037)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '17399', name: '3-10-11 (27, 3959)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '37676', name: '3-9-10-11 (15, 271)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '37460', name: '3-10-11 (27, 303)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '37462', name: '3-10-11-19 (12, 302)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '35383', name: '3-10-11-15 (12, 657)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '38072', name: '3-10-11 (12, 198)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '37533', name: '3-10-11-19 (13, 292)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '35902', name: '3-10-11-15-19 (12, 586)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } },
    { data: { id: '35551', name: '3-9-10-11 (15, 639)', faveColor: '#6FB1FC', faveShape: 'roundrectangle' } }
  ], 
  
  edges: [
    { data: { id: '31362-0', weight: 1, source: '31362', target: '0', faveColor: 'black' } },
    { data: { id: '33014-0', weight: 1, source: '33014', target: '0', faveColor: 'black' } },
    { data: { id: '17399-0', weight: 1, source: '17399', target: '0', faveColor: 'black' } },
    { data: { id: '37676-0', weight: 1, source: '37676', target: '0', faveColor: 'black' } },
    { data: { id: '37676-37462', weight: 1, source: '37676', target: '37462', faveColor: '#6FB1FC' } },
    { data: { id: '37460-0', weight: 1, source: '37460', target: '0', faveColor: 'black' } },
    { data: { id: '37462-37676', weight: 1, source: '37462', target: '37676', faveColor: 'black' } },
    { data: { id: '37462-37460', weight: 1, source: '37462', target: '37460', faveColor: 'black' } },
    { data: { id: '37462-35383', weight: 1, source: '37462', target: '35383', faveColor: 'black' } },
    { data: { id: '37462-33014', weight: 1, source: '37462', target: '33014', faveColor: 'black' } },
    { data: { id: '37462-17399', weight: 1, source: '37462', target: '17399', faveColor: 'black' } },
    { data: { id: '37462-0', weight: 1, source: '37462', target: '0', faveColor: 'black' } },
    { data: { id: '37462-38072', weight: 1, source: '37462', target: '38072', faveColor: '#6FB1FC' } },
    { data: { id: '37462-35551', weight: 1, source: '37462', target: '35551', faveColor: '#6FB1FC' } },
    { data: { id: '37462-31362', weight: 1, source: '37462', target: '31362', faveColor: '#6FB1FC' } },
    { data: { id: '35383-37676', weight: 1, source: '35383', target: '37676', faveColor: 'black' } },
    { data: { id: '35383-0', weight: 1, source: '35383', target: '0', faveColor: 'black' } },
    { data: { id: '35383-35551', weight: 1, source: '35383', target: '35551', faveColor: '#6FB1FC' } },
    { data: { id: '38072-0', weight: 1, source: '38072', target: '0', faveColor: 'black' } },
    { data: { id: '37533-37676', weight: 1, source: '37533', target: '37676', faveColor: 'black' } },
    { data: { id: '37533-37460', weight: 1, source: '37533', target: '37460', faveColor: 'black' } },
    { data: { id: '37533-35383', weight: 1, source: '37533', target: '35383', faveColor: 'black' } },
    { data: { id: '37533-33014', weight: 1, source: '37533', target: '33014', faveColor: 'black' } },
    { data: { id: '37533-17399', weight: 1, source: '37533', target: '17399', faveColor: 'black' } },
    { data: { id: '37533-0', weight: 1, source: '37533', target: '0', faveColor: 'black' } },
    { data: { id: '37533-38072', weight: 1, source: '37533', target: '38072', faveColor: '#6FB1FC' } },
    { data: { id: '37533-35551', weight: 1, source: '37533', target: '35551', faveColor: '#6FB1FC' } },
    { data: { id: '37533-31362', weight: 1, source: '37533', target: '31362', faveColor: '#6FB1FC' } },
    { data: { id: '35902-37676', weight: 1, source: '35902', target: '37676', faveColor: 'black' } },
    { data: { id: '35902-37460', weight: 1, source: '35902', target: '37460', faveColor: 'black' } },
    { data: { id: '35902-35383', weight: 1, source: '35902', target: '35383', faveColor: 'black' } },
    { data: { id: '35902-33014', weight: 1, source: '35902', target: '33014', faveColor: 'black' } },
    { data: { id: '35902-17399', weight: 1, source: '35902', target: '17399', faveColor: 'black' } },
    { data: { id: '35902-0', weight: 1, source: '35902', target: '0', faveColor: 'black' } },
    { data: { id: '35902-38072', weight: 1, source: '35902', target: '38072', faveColor: '#6FB1FC' } },
    { data: { id: '35902-35551', weight: 1, source: '35902', target: '35551', faveColor: '#6FB1FC' } },
    { data: { id: '35902-31362', weight: 1, source: '35902', target: '31362', faveColor: '#6FB1FC' } },
    { data: { id: '35551-0', weight: 1, source: '35551', target: '0', faveColor: 'black' } },
    { data: { id: '35551-37462', weight: 1, source: '35551', target: '37462', faveColor: '#6FB1FC' } }
  ]
  },
  
  layout: {
    name: 'cose',
    animate: false,
    directed: true,
    padding: 10,
  }
});

}); // on dom ready
